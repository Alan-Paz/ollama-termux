-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: mysql-automacao-cfo-energia.alwaysdata.net
-- Generation Time: Nov 18, 2025 at 10:34 PM
-- Server version: 10.11.14-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automacao-cfo-energia_cfoenergia`
--

DELIMITER $$
--
-- Procedures
--
$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ACAO_PAGAMENTO`
--

CREATE TABLE `ACAO_PAGAMENTO` (
  `id` int(11) NOT NULL,
  `Acoes` varchar(100) NOT NULL,
  `Numero` varchar(50) DEFAULT NULL,
  `Tipo` varchar(50) DEFAULT NULL,
  `Medicao` varchar(100) DEFAULT NULL,
  `Descricao` text DEFAULT NULL,
  `Registro` datetime DEFAULT current_timestamp(),
  `Variacao` decimal(10,2) DEFAULT NULL,
  `Debito_Automatico` tinyint(1) DEFAULT 0,
  `Numero_Debito_Automatico` varchar(50) DEFAULT NULL,
  `Classificacao_Pagamento` varchar(100) DEFAULT NULL,
  `Status` varchar(50) DEFAULT 'Ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ACAO_PAGAMENTO`
--

INSERT INTO `ACAO_PAGAMENTO` (`id`, `Acoes`, `Numero`, `Tipo`, `Medicao`, `Descricao`, `Registro`, `Variacao`, `Debito_Automatico`, `Numero_Debito_Automatico`, `Classificacao_Pagamento`, `Status`) VALUES
(1, 'ENERGIA ELÉTRICA', '242', 'ENERGIA - -MEE112', 'ENERGIA - -MEE112', 'MEE112', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(2, 'ENERGIA ELÉTRICA', '868', 'ENERGIA - (L150) DON PATTO - MEE259', 'ENERGIA - (L150) DON PATTO - MEE259', 'MEE259', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(3, 'ENERGIA ELÉTRICA', '869', 'ENERGIA - (L151/L152) ARTELASSE - MEE260', 'ENERGIA - (L151/L152) ARTELASSE - MEE260', 'MEE260', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(4, 'ENERGIA ELÉTRICA', '870', 'ENERGIA - (L153/L154) GREGORY - MEE261', 'ENERGIA - (L153/L154) GREGORY - MEE261', 'MEE261', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(5, 'ENERGIA ELÉTRICA', '871', 'ENERGIA - (L155) CASA ALMEIDA - MEE262', 'ENERGIA - (L155) CASA ALMEIDA - MEE262', 'MEE262', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(6, 'ENERGIA ELÉTRICA', '872', 'ENERGIA - (L156/L157/L158) VANS - MEE263', 'ENERGIA - (L156/L157/L158) VANS - MEE263', 'MEE263', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(7, 'ENERGIA ELÉTRICA', '873', 'ENERGIA - (L159) CACAU NOIR - MEE264', 'ENERGIA - (L159) CACAU NOIR - MEE264', 'MEE264', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(8, 'ENERGIA ELÉTRICA', '874', 'ENERGIA - (L160) BLUE MAN - MEE265', 'ENERGIA - (L160) BLUE MAN - MEE265', 'MEE265', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(9, 'ENERGIA ELÉTRICA', '875', 'ENERGIA - (L161) ÁGUA DE COCO - MEE266', 'ENERGIA - (L161) ÁGUA DE COCO - MEE266', 'MEE266', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(10, 'ENERGIA ELÉTRICA', '876', 'ENERGIA - (L162/L163) - MEE267', 'ENERGIA - (L162/L163) - MEE267', 'MEE267', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(11, 'ENERGIA ELÉTRICA', '877', 'ENERGIA - (L164/L165) IORANE - MEE268', 'ENERGIA - (L164/L165) IORANE - MEE268', 'MEE268', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(12, 'ENERGIA ELÉTRICA', '878', 'ENERGIA - (L166A) AGILITA - MEE269', 'ENERGIA - (L166A) AGILITA - MEE269', 'MEE269', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(13, 'ENERGIA ELÉTRICA', '880', 'ENERGIA - (L167/L214/L215) BROOKSFIELD D - MEE271', 'ENERGIA - (L167/L214/L215) BROOKSFIELD DONNA - MEE271', 'MEE271', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(14, 'ENERGIA ELÉTRICA', '884', 'ENERGIA - (L168) IL BARISTA - MEE275', 'ENERGIA - (L168) IL BARISTA - MEE275', 'MEE275', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(15, 'ENERGIA ELÉTRICA', '879', 'ENERGIA - (L168B) BROOKSFIELD - MEE270', 'ENERGIA - (L168B) BROOKSFIELD - MEE270', 'MEE270', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(16, 'ENERGIA ELÉTRICA', '885', 'ENERGIA - (L169/L170) ZAK - MEE276', 'ENERGIA - (L169/L170) ZAK - MEE276', 'MEE276', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(17, 'ENERGIA ELÉTRICA', '886', 'ENERGIA - (L171) ARBO - MEE277', 'ENERGIA - (L171) ARBO - MEE277', 'MEE277', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(18, 'ENERGIA ELÉTRICA', '887', 'ENERGIA - (L172) ANTIX - MEE278', 'ENERGIA - (L172) ANTIX - MEE278', 'MEE278', '2025-11-12 20:07:08', 0.00, 0, NULL, NULL, 'ATIVO'),
(19, 'ENERGIA ELÉTRICA', '888', 'ENERGIA - (L173/L174) TRYAMON - MEE279', 'ENERGIA - (L173/L174) TRYAMON - MEE279', 'MEE279', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(20, 'ENERGIA ELÉTRICA', '889', 'ENERGIA - (L175) M MARTAN - MEE280', 'ENERGIA - (L175) M MARTAN - MEE280', 'MEE280', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(21, 'ENERGIA ELÉTRICA', '890', 'ENERGIA - (L176) - MEE281', 'ENERGIA - (L176) - MEE281', 'MEE281', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(22, 'ENERGIA ELÉTRICA', '891', 'ENERGIA - (L177) PAULA TORRES - MEE282', 'ENERGIA - (L177) PAULA TORRES - MEE282', 'MEE282', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(23, 'ENERGIA ELÉTRICA', '892', 'ENERGIA - (L178) BIOMUNDO - MEE283', 'ENERGIA - (L178) BIOMUNDO - MEE283', 'MEE283', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(24, 'ENERGIA ELÉTRICA', '893', 'ENERGIA - (L179/L180/L181) - MEE284', 'ENERGIA - (L179/L180/L181) - MEE284', 'MEE284', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(25, 'ENERGIA ELÉTRICA', '894', 'ENERGIA - (L182/L183) DENGO - MEE285', 'ENERGIA - (L182/L183) DENGO - MEE285', 'MEE285', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(26, 'ENERGIA ELÉTRICA', '895', 'ENERGIA - (L184/L185) OAKLEY - MEE286', 'ENERGIA - (L184/L185) OAKLEY - MEE286', 'MEE286', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(27, 'ENERGIA ELÉTRICA', '896', 'ENERGIA - (L186) - MEE287', 'ENERGIA - (L186) - MEE287', 'MEE287', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(28, 'ENERGIA ELÉTRICA', '897', 'ENERGIA - (L187) LE CRUISET - MEE288', 'ENERGIA - (L187) LE CRUISET - MEE288', 'MEE288', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(29, 'ENERGIA ELÉTRICA', '898', 'ENERGIA - (L188/L189) FILLITY - MEE289', 'ENERGIA - (L188/L189) FILLITY - MEE289', 'MEE289', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(30, 'ENERGIA ELÉTRICA', '899', 'ENERGIA - (L190) KIKA SIMONSEN - MEE290', 'ENERGIA - (L190) KIKA SIMONSEN - MEE290', 'MEE290', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(31, 'ENERGIA ELÉTRICA', '900', 'ENERGIA - (L191) LENNY NIEMEYER - MEE291', 'ENERGIA - (L191) LENNY NIEMEYER - MEE291', 'MEE291', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(32, 'ENERGIA ELÉTRICA', '901', 'ENERGIA - (L192) BLANC TOTYS - MEE292', 'ENERGIA - (L192) BLANC TOTYS - MEE292', 'MEE292', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(33, 'ENERGIA ELÉTRICA', '902', 'ENERGIA - (L193/L194/L195) CAROL BASSI - MEE293', 'ENERGIA - (L193/L194/L195) CAROL BASSI - MEE293', 'MEE293', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(34, 'ENERGIA ELÉTRICA', '919', 'ENERGIA - (L196) HUGO BOSS - MEE310', 'ENERGIA - (L196) HUGO BOSS - MEE310', 'MEE310', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(35, 'ENERGIA ELÉTRICA', '918', 'ENERGIA - (L197) PATBO - MEE309', 'ENERGIA - (L197) PATBO - MEE309', 'MEE309', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO'),
(36, 'ENERGIA ELÉTRICA', '917', 'ENERGIA - (L198) ALEXANDRE BIRMAN - MEE308', 'ENERGIA - (L198) ALEXANDRE BIRMAN - MEE308', 'MEE308', '2025-11-12 20:09:09', 0.00, 0, NULL, NULL, 'ATIVO');

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_CONSOLIDADO`
--

CREATE TABLE `ENERGIA_GERAL_CONSOLIDADO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL,
  `id_unidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_CONSOLIDADO`
--

INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`id`, `Data`, `Medicao`, `Loja`, `Consumo`, `id_unidade`) VALUES
(1, '2025-11-18 22:28:21', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 41641, 652),
(2, '2025-11-18 22:28:21', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 31048, 0),
(3, '2025-11-18 22:28:21', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 314242, 655),
(4, '2025-11-18 22:28:21', 'ENERGIA_L303_Polimaia_MEE188', 'Polimaia', 44475, 0),
(5, '2025-11-18 22:28:21', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123825, 656),
(6, '2025-11-18 22:28:21', 'ENERGIA_L150_DONPATTO_MEE259', 'Don Patto', 71779.9, 282),
(7, '2025-11-18 22:28:21', 'ENERGIA_L168_ILBARISTA_MEE275', 'IL BARISTA', 51299.2, 802),
(8, '2025-11-18 22:28:21', 'ENERGIA_L169_L170_ZAK_MEE276', 'ZAK', 120961, 740),
(9, '2025-11-18 22:28:21', 'ENERGIA_L193_L194_L195_CAROLBASSI_MEE293', 'CAROL BASSI', NULL, 643);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_DELTA`
--

CREATE TABLE `ENERGIA_GERAL_DELTA` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `ConsumoAtual` float DEFAULT NULL,
  `ConsumoAnterior` float DEFAULT NULL,
  `Delta` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_DELTA`
--

INSERT INTO `ENERGIA_GERAL_DELTA` (`id`, `Data`, `Medicao`, `Loja`, `ConsumoAtual`, `ConsumoAnterior`, `Delta`) VALUES
(28, '2025-11-05 21:30:21', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30562, 30515.1, 46.8613),
(29, '2025-11-05 21:30:21', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40944.8, 40876.8, 67.9883),
(30, '2025-11-05 21:30:21', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123825, 123815, 10),
(31, '2025-11-05 21:30:21', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 309273, 308709, 564.219),
(32, '2025-11-11 03:37:18', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 41202.6, 40876.8, 325.785),
(33, '2025-11-11 03:37:18', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30740.3, 30515.1, 225.18),
(34, '2025-11-11 03:37:18', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 311196, 308709, 2487.06),
(35, '2025-11-11 03:37:18', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123825, 123815, 10);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_HISTORICO`
--

CREATE TABLE `ENERGIA_GERAL_HISTORICO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_HISTORICO`
--

INSERT INTO `ENERGIA_GERAL_HISTORICO` (`id`, `Data`, `Medicao`, `Loja`, `Consumo`) VALUES
(1, '2025-11-02 13:31:38', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8),
(2, '2025-11-02 13:31:38', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30515.1),
(3, '2025-11-02 13:31:38', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 308709),
(7, '2025-11-03 03:46:55', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123815);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L150_DONPATTO_MEE259`
--

CREATE TABLE `ENERGIA_L150_DONPATTO_MEE259` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L150',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L150_DONPATTO_MEE259',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L150_DONPATTO_MEE259`
--

INSERT INTO `ENERGIA_L150_DONPATTO_MEE259` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L150', 71780, '2025-11-12 22:45:37', 'ENERGIA_L150_DONPATTO_MEE259', 'SCADA_MYSQL', NULL, '2025-11-12 20:28:17', NULL, 71779.9);

--
-- Triggers `ENERGIA_L150_DONPATTO_MEE259`
--
DELIMITER $$
CREATE TRIGGER `DONPATTO` BEFORE UPDATE ON `ENERGIA_L150_DONPATTO_MEE259` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L151_L152_ARTELASSE_MEE260`
--

CREATE TABLE `ENERGIA_L151_L152_ARTELASSE_MEE260` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L151/L152',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L151_L152_ARTELASSE_MEE260',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L151_L152_ARTELASSE_MEE260`
--

INSERT INTO `ENERGIA_L151_L152_ARTELASSE_MEE260` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L151/L152', 1, '2025-11-12 22:41:32', 'ENERGIA_L151_L152_ARTELASSE_MEE260', 'SCADA_MYSQL', NULL, '2025-11-12 22:41:32', NULL, NULL);

--
-- Triggers `ENERGIA_L151_L152_ARTELASSE_MEE260`
--
DELIMITER $$
CREATE TRIGGER `ENERGIA_L151_L152_ARTELASSE_MEE260` BEFORE UPDATE ON `ENERGIA_L151_L152_ARTELASSE_MEE260` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L153_L154_GREGORY_MEE261`
--

CREATE TABLE `ENERGIA_L153_L154_GREGORY_MEE261` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L153/L154',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L153_L154_GREGORY_MEE261',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L153_L154_GREGORY_MEE261`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L153_L154_GREGORY_MEE261` BEFORE UPDATE ON `ENERGIA_L153_L154_GREGORY_MEE261` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L155_CASA_ALMEIDA_MEE262`
--

CREATE TABLE `ENERGIA_L155_CASA_ALMEIDA_MEE262` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L155',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L155_CASA_ALMEIDA_MEE262',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L155_CASA_ALMEIDA_MEE262`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L155_CASA_ALMEIDA_MEE262` BEFORE UPDATE ON `ENERGIA_L155_CASA_ALMEIDA_MEE262` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L156_L157_L158_VANS_MEE263`
--

CREATE TABLE `ENERGIA_L156_L157_L158_VANS_MEE263` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L156/L157/L158',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L156_L157_L158_VANS_MEE263',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L156_L157_L158_VANS_MEE263`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L156_L157_L158_VANS_MEE263` BEFORE UPDATE ON `ENERGIA_L156_L157_L158_VANS_MEE263` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L159_CACAUNOIR_MEE264`
--

CREATE TABLE `ENERGIA_L159_CACAUNOIR_MEE264` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L159',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L159_CACAUNOIR_MEE264',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L159_CACAUNOIR_MEE264`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L159_CACAUNOIR_MEE264` BEFORE UPDATE ON `ENERGIA_L159_CACAUNOIR_MEE264` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L160_BLUEMAN_MEE265`
--

CREATE TABLE `ENERGIA_L160_BLUEMAN_MEE265` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L160',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L160_BLUEMAN_MEE265',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L160_BLUEMAN_MEE265`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L160_BLUEMAN_MEE265` BEFORE UPDATE ON `ENERGIA_L160_BLUEMAN_MEE265` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L161_AGUADECOCO_MEE266`
--

CREATE TABLE `ENERGIA_L161_AGUADECOCO_MEE266` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L161',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L161_AGUADECOCO_MEE266',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L161_AGUADECOCO_MEE266`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L161_AGUADECOCO_MEE266` BEFORE UPDATE ON `ENERGIA_L161_AGUADECOCO_MEE266` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L164_L165_IORANE_MEE268`
--

CREATE TABLE `ENERGIA_L164_L165_IORANE_MEE268` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L164/L165',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L164_L165_IORANE_MEE268',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L164_L165_IORANE_MEE268`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L164_L165_IORANE_MEE268` BEFORE UPDATE ON `ENERGIA_L164_L165_IORANE_MEE268` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L166A_AGILITA_MEE269`
--

CREATE TABLE `ENERGIA_L166A_AGILITA_MEE269` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L166A',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L166A_AGILITA_MEE269',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L166A_AGILITA_MEE269`
--

INSERT INTO `ENERGIA_L166A_AGILITA_MEE269` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(2, 'L166A', 49758, '2025-11-18 22:32:24', 'ENERGIA_L166A_AGILITA_MEE269', 'SCADA_MYSQL', NULL, '2025-11-18 13:46:14', NULL, 49757.6);

--
-- Triggers `ENERGIA_L166A_AGILITA_MEE269`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L166A_AGILITA_MEE269` BEFORE UPDATE ON `ENERGIA_L166A_AGILITA_MEE269` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
--

CREATE TABLE `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L167/L214/L215',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
--

INSERT INTO `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L167/L214/L215', 80524, '2025-11-18 22:32:17', 'ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271', 'SCADA_MYSQL', NULL, '2025-11-17 18:57:16', 1.00, 80524);

--
-- Triggers `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271` BEFORE UPDATE ON `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L168_ILBARISTA_MEE275`
--

CREATE TABLE `ENERGIA_L168_ILBARISTA_MEE275` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L168',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L168_ILBARISTA_MEE275',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L168_ILBARISTA_MEE275`
--

INSERT INTO `ENERGIA_L168_ILBARISTA_MEE275` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L168', 51299, '2025-11-18 22:31:39', 'ENERGIA_L168_ILBARISTA_MEE275', 'SCADA_MYSQL', NULL, '2025-11-18 21:37:00', NULL, 51299.5);

--
-- Triggers `ENERGIA_L168_ILBARISTA_MEE275`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L168_ILBARISTA_MEE275` BEFORE UPDATE ON `ENERGIA_L168_ILBARISTA_MEE275` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L169_L170_ZAK_MEE276`
--

CREATE TABLE `ENERGIA_L169_L170_ZAK_MEE276` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L169/L170',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L169_L170_ZAK_MEE276',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L169_L170_ZAK_MEE276`
--

INSERT INTO `ENERGIA_L169_L170_ZAK_MEE276` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L169/L170', 120961, '2025-11-18 22:28:11', 'ENERGIA_L169_L170_ZAK_MEE276', 'SCADA_MYSQL', NULL, '2025-11-18 22:00:06', NULL, 120961);

--
-- Triggers `ENERGIA_L169_L170_ZAK_MEE276`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L169_L170_ZAK_MEE276` BEFORE UPDATE ON `ENERGIA_L169_L170_ZAK_MEE276` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
--

CREATE TABLE `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L193/L194/L195',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L193_L194_L195_CAROLBASSI_MEE293',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Triggers `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L193_L194_L195_CAROLBASSI_MEE293` BEFORE UPDATE ON `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301A_Vivara_MEE186`
--

CREATE TABLE `ENERGIA_L301A_Vivara_MEE186` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301A',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301A_Vivara_MEE186',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301A_Vivara_MEE186`
--

INSERT INTO `ENERGIA_L301A_Vivara_MEE186` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301A', 1, '2025-11-11 03:16:37', 'ENERGIA_L301A_Vivara_MEE186', 'SCADA_MYSQL', NULL, '2025-11-11 03:16:37', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

CREATE TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301B',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301B_Jorge_Bischoff_MEE185',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

INSERT INTO `ENERGIA_L301B_Jorge_Bischoff_MEE185` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301B', 40761, '2025-11-18 22:32:23', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'SCADA_MYSQL', NULL, '2025-10-29 23:50:52', NULL, 41641.4);

--
-- Triggers `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301B` AFTER INSERT ON `ENERGIA_L301B_Jorge_Bischoff_MEE185` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Jorge Bischoff', NEW.Consumo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301D_FacasDavila_MEE183`
--

CREATE TABLE `ENERGIA_L301D_FacasDavila_MEE183` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301D',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301D_FacasDavila_MEE183',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301D_FacasDavila_MEE183`
--

INSERT INTO `ENERGIA_L301D_FacasDavila_MEE183` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301D', 1, '2025-11-11 03:16:20', 'ENERGIA_L301D_FacasDavila_MEE183', 'SCADA_MYSQL', NULL, '2025-11-11 03:16:20', NULL, NULL);

--
-- Triggers `ENERGIA_L301D_FacasDavila_MEE183`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L301D_FacasDavila_MEE183` BEFORE UPDATE ON `ENERGIA_L301D_FacasDavila_MEE183` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301E_NutraFit_MEE182`
--

CREATE TABLE `ENERGIA_L301E_NutraFit_MEE182` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301E',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301E_NutraFit_MEE182',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301E_NutraFit_MEE182`
--

INSERT INTO `ENERGIA_L301E_NutraFit_MEE182` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301E', 1, '2025-11-11 03:16:11', 'ENERGIA_L301E_NutraFit_MEE182', 'SCADA_MYSQL', NULL, '2025-11-11 03:16:11', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301F_American_Cookies_MEE181`
--

CREATE TABLE `ENERGIA_L301F_American_Cookies_MEE181` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301F',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301F_American_Cookies_MEE181',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301F_American_Cookies_MEE181`
--

INSERT INTO `ENERGIA_L301F_American_Cookies_MEE181` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301F', 31048, '2025-11-18 22:32:11', 'ENERGIA_L301F_American_Cookies_MEE181', 'SCADA_MYSQL', NULL, '2025-10-29 22:17:46', NULL, 31048.2);

--
-- Triggers `ENERGIA_L301F_American_Cookies_MEE181`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301F` AFTER INSERT ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'American Cookies', NEW.Consumo);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_data_value_before_update` BEFORE UPDATE ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L302_Reebok_MEE187`
--

CREATE TABLE `ENERGIA_L302_Reebok_MEE187` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L302',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L302_Reebok_MEE187',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L302_Reebok_MEE187`
--

INSERT INTO `ENERGIA_L302_Reebok_MEE187` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L302', NULL, '2025-11-18 22:32:12', 'ENERGIA_L302_Reebok_MEE187', 'SCADA_MYSQL', NULL, '2025-11-02 03:19:41', NULL, 314244);

--
-- Triggers `ENERGIA_L302_Reebok_MEE187`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L302` AFTER INSERT ON `ENERGIA_L302_Reebok_MEE187` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Reebok', NEW.Consumo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L303_Polimaia_MEE188`
--

CREATE TABLE `ENERGIA_L303_Polimaia_MEE188` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L303',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L303_Polimaia_MEE188',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L303_Polimaia_MEE188`
--

INSERT INTO `ENERGIA_L303_Polimaia_MEE188` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L303', 1, '2025-11-11 11:09:25', 'ENERGIA_L303_Polimaia_MEE188', 'SCADA_MYSQL', NULL, '2025-11-10 22:38:41', NULL, 44475);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L304_Ophicina_MEE189`
--

CREATE TABLE `ENERGIA_L304_Ophicina_MEE189` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L304',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L304_Ophicina_MEE189',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L304_Ophicina_MEE189`
--

INSERT INTO `ENERGIA_L304_Ophicina_MEE189` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L304', 1, '2025-11-11 03:15:55', 'ENERGIA_L304_Ophicina_MEE189', 'SCADA_MYSQL', NULL, '2025-11-11 03:15:55', NULL, NULL);

--
-- Triggers `ENERGIA_L304_Ophicina_MEE189`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L304_Ophicina_MEE189` BEFORE UPDATE ON `ENERGIA_L304_Ophicina_MEE189` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L305_Kipling_MEE190`
--

CREATE TABLE `ENERGIA_L305_Kipling_MEE190` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L305',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L305_Kipling_MEE190',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L305_Kipling_MEE190`
--

INSERT INTO `ENERGIA_L305_Kipling_MEE190` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L305', NULL, '2025-11-03 10:43:21', 'ENERGIA_L305_Kipling_MEE190', 'SCADA_MYSQL', NULL, '2025-11-03 03:05:46', NULL, 123825);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L306_LoftyStyle_MEE191`
--

CREATE TABLE `ENERGIA_L306_LoftyStyle_MEE191` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L306',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L306_LoftyStyle_MEE191',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L306_LoftyStyle_MEE191`
--

INSERT INTO `ENERGIA_L306_LoftyStyle_MEE191` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(2, 'L306', NULL, '2025-11-10 20:38:36', 'ENERGIA_L306_LoftyStyle_MEE191', 'SCADA_MYSQL', NULL, '2025-11-10 20:38:36', NULL, 1);

--
-- Triggers `ENERGIA_L306_LoftyStyle_MEE191`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L306_LoftyStyle_MEE191` BEFORE UPDATE ON `ENERGIA_L306_LoftyStyle_MEE191` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L307_MrKitsch_MEE192`
--

CREATE TABLE `ENERGIA_L307_MrKitsch_MEE192` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L307',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L307_MrKitsch_MEE192',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L307_MrKitsch_MEE192`
--

INSERT INTO `ENERGIA_L307_MrKitsch_MEE192` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L307', 1, '2025-11-11 03:15:30', 'ENERGIA_L307_MrKitsch_MEE192', 'SCADA_MYSQL', NULL, '2025-11-11 03:15:30', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L308_Criattip_MEE193`
--

CREATE TABLE `ENERGIA_L308_Criattip_MEE193` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L308',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L308_Criattip_MEE193',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L308_Criattip_MEE193`
--

INSERT INTO `ENERGIA_L308_Criattip_MEE193` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L308', 1, '2025-11-11 03:15:19', 'ENERGIA_L308_Criattip_MEE193', 'SCADA_MYSQL', NULL, '2025-11-11 03:15:19', NULL, NULL);

--
-- Triggers `ENERGIA_L308_Criattip_MEE193`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L308_Criattip_MEE193` BEFORE UPDATE ON `ENERGIA_L308_Criattip_MEE193` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L309_310_BananaDanger_MEE194`
--

CREATE TABLE `ENERGIA_L309_310_BananaDanger_MEE194` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L309/310',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L309_310_BananaDanger_MEE194',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L309_310_BananaDanger_MEE194`
--

INSERT INTO `ENERGIA_L309_310_BananaDanger_MEE194` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(2, 'L309/310', NULL, '2025-11-10 20:38:13', 'ENERGIA_L309_310_BananaDanger_MEE194', 'SCADA_MYSQL', NULL, '2025-11-10 20:38:13', NULL, 1);

--
-- Triggers `ENERGIA_L309_310_BananaDanger_MEE194`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L309_310_BananaDanger_MEE194` BEFORE UPDATE ON `ENERGIA_L309_310_BananaDanger_MEE194` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L398_IceRoll_MEE222`
--

CREATE TABLE `ENERGIA_L398_IceRoll_MEE222` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L398',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L398_IceRoll_MEE222',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L398_IceRoll_MEE222`
--

INSERT INTO `ENERGIA_L398_IceRoll_MEE222` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L398', NULL, '2025-11-11 03:14:41', 'ENERGIA_L398_IceRoll_MEE222', 'SCADA_MYSQL', NULL, '2025-11-11 03:14:41', NULL, NULL),
(2, 'L398', 1, '2025-11-11 03:14:41', 'ENERGIA_L398_IceRoll_MEE222', 'SCADA_MYSQL', NULL, '2025-11-11 03:14:41', NULL, NULL);

--
-- Triggers `ENERGIA_L398_IceRoll_MEE222`
--
DELIMITER $$
CREATE TRIGGER `update_ENERGIA_L398_IceRoll_MEE222` BEFORE UPDATE ON `ENERGIA_L398_IceRoll_MEE222` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `id_unidade`
--

CREATE TABLE `id_unidade` (
  `id_unidade` int(11) NOT NULL,
  `cd_unidade` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `id_unidade`
--

INSERT INTO `id_unidade` (`id_unidade`, `cd_unidade`) VALUES
(282, 'Don Patto - L150'),
(312, 'Brooksfield Donna - L166B'),
(652, 'Jorge Bischoff - L301B'),
(655, 'Reebok - L302'),
(656, 'Kipling - L305');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ACAO_PAGAMENTO`
--
ALTER TABLE `ACAO_PAGAMENTO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_DELTA`
--
ALTER TABLE `ENERGIA_GERAL_DELTA`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L150_DONPATTO_MEE259`
--
ALTER TABLE `ENERGIA_L150_DONPATTO_MEE259`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L151_L152_ARTELASSE_MEE260`
--
ALTER TABLE `ENERGIA_L151_L152_ARTELASSE_MEE260`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L153_L154_GREGORY_MEE261`
--
ALTER TABLE `ENERGIA_L153_L154_GREGORY_MEE261`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L155_CASA_ALMEIDA_MEE262`
--
ALTER TABLE `ENERGIA_L155_CASA_ALMEIDA_MEE262`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L156_L157_L158_VANS_MEE263`
--
ALTER TABLE `ENERGIA_L156_L157_L158_VANS_MEE263`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L159_CACAUNOIR_MEE264`
--
ALTER TABLE `ENERGIA_L159_CACAUNOIR_MEE264`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L160_BLUEMAN_MEE265`
--
ALTER TABLE `ENERGIA_L160_BLUEMAN_MEE265`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L161_AGUADECOCO_MEE266`
--
ALTER TABLE `ENERGIA_L161_AGUADECOCO_MEE266`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L164_L165_IORANE_MEE268`
--
ALTER TABLE `ENERGIA_L164_L165_IORANE_MEE268`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L166A_AGILITA_MEE269`
--
ALTER TABLE `ENERGIA_L166A_AGILITA_MEE269`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
--
ALTER TABLE `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L168_ILBARISTA_MEE275`
--
ALTER TABLE `ENERGIA_L168_ILBARISTA_MEE275`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L169_L170_ZAK_MEE276`
--
ALTER TABLE `ENERGIA_L169_L170_ZAK_MEE276`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
--
ALTER TABLE `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301A_Vivara_MEE186`
--
ALTER TABLE `ENERGIA_L301A_Vivara_MEE186`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301D_FacasDavila_MEE183`
--
ALTER TABLE `ENERGIA_L301D_FacasDavila_MEE183`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301E_NutraFit_MEE182`
--
ALTER TABLE `ENERGIA_L301E_NutraFit_MEE182`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L303_Polimaia_MEE188`
--
ALTER TABLE `ENERGIA_L303_Polimaia_MEE188`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L304_Ophicina_MEE189`
--
ALTER TABLE `ENERGIA_L304_Ophicina_MEE189`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L305_Kipling_MEE190`
--
ALTER TABLE `ENERGIA_L305_Kipling_MEE190`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L306_LoftyStyle_MEE191`
--
ALTER TABLE `ENERGIA_L306_LoftyStyle_MEE191`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L307_MrKitsch_MEE192`
--
ALTER TABLE `ENERGIA_L307_MrKitsch_MEE192`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L308_Criattip_MEE193`
--
ALTER TABLE `ENERGIA_L308_Criattip_MEE193`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L309_310_BananaDanger_MEE194`
--
ALTER TABLE `ENERGIA_L309_310_BananaDanger_MEE194`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L398_IceRoll_MEE222`
--
ALTER TABLE `ENERGIA_L398_IceRoll_MEE222`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `id_unidade`
--
ALTER TABLE `id_unidade`
  ADD PRIMARY KEY (`id_unidade`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ACAO_PAGAMENTO`
--
ALTER TABLE `ACAO_PAGAMENTO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=37;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=313;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_DELTA`
--
ALTER TABLE `ENERGIA_GERAL_DELTA`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `ENERGIA_L150_DONPATTO_MEE259`
--
ALTER TABLE `ENERGIA_L150_DONPATTO_MEE259`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L151_L152_ARTELASSE_MEE260`
--
ALTER TABLE `ENERGIA_L151_L152_ARTELASSE_MEE260`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L153_L154_GREGORY_MEE261`
--
ALTER TABLE `ENERGIA_L153_L154_GREGORY_MEE261`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L155_CASA_ALMEIDA_MEE262`
--
ALTER TABLE `ENERGIA_L155_CASA_ALMEIDA_MEE262`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L156_L157_L158_VANS_MEE263`
--
ALTER TABLE `ENERGIA_L156_L157_L158_VANS_MEE263`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L159_CACAUNOIR_MEE264`
--
ALTER TABLE `ENERGIA_L159_CACAUNOIR_MEE264`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L160_BLUEMAN_MEE265`
--
ALTER TABLE `ENERGIA_L160_BLUEMAN_MEE265`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L161_AGUADECOCO_MEE266`
--
ALTER TABLE `ENERGIA_L161_AGUADECOCO_MEE266`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L164_L165_IORANE_MEE268`
--
ALTER TABLE `ENERGIA_L164_L165_IORANE_MEE268`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L166A_AGILITA_MEE269`
--
ALTER TABLE `ENERGIA_L166A_AGILITA_MEE269`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
--
ALTER TABLE `ENERGIA_L167_L214_L215_BROOKSFIELDDONNA_MEE271`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L168_ILBARISTA_MEE275`
--
ALTER TABLE `ENERGIA_L168_ILBARISTA_MEE275`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L169_L170_ZAK_MEE276`
--
ALTER TABLE `ENERGIA_L169_L170_ZAK_MEE276`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
--
ALTER TABLE `ENERGIA_L193_L194_L195_CAROLBASSI_MEE293`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L301A_Vivara_MEE186`
--
ALTER TABLE `ENERGIA_L301A_Vivara_MEE186`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L301D_FacasDavila_MEE183`
--
ALTER TABLE `ENERGIA_L301D_FacasDavila_MEE183`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L301E_NutraFit_MEE182`
--
ALTER TABLE `ENERGIA_L301E_NutraFit_MEE182`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ENERGIA_L303_Polimaia_MEE188`
--
ALTER TABLE `ENERGIA_L303_Polimaia_MEE188`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L304_Ophicina_MEE189`
--
ALTER TABLE `ENERGIA_L304_Ophicina_MEE189`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L305_Kipling_MEE190`
--
ALTER TABLE `ENERGIA_L305_Kipling_MEE190`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L306_LoftyStyle_MEE191`
--
ALTER TABLE `ENERGIA_L306_LoftyStyle_MEE191`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L307_MrKitsch_MEE192`
--
ALTER TABLE `ENERGIA_L307_MrKitsch_MEE192`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L308_Criattip_MEE193`
--
ALTER TABLE `ENERGIA_L308_Criattip_MEE193`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L309_310_BananaDanger_MEE194`
--
ALTER TABLE `ENERGIA_L309_310_BananaDanger_MEE194`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L398_IceRoll_MEE222`
--
ALTER TABLE `ENERGIA_L398_IceRoll_MEE222`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`438522_automacao`@`%` EVENT `salvar_historico_consolidado` ON SCHEDULE EVERY 15 DAY STARTS '2025-11-01 12:43:22' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  INSERT INTO ENERGIA_GERAL_HISTORICO (Data, Medicao, Loja, Consumo)
  SELECT Data, Medicao, Loja, Consumo
  FROM ENERGIA_GERAL_CONSOLIDADO;
END$$

CREATE DEFINER=`438522`@`%` EVENT `ENERGIA_CONSOLIDADO` ON SCHEDULE EVERY 3 SECOND STARTS '2025-11-02 09:11:51' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN

REPLACE INTO ENERGIA_GERAL_CONSOLIDADO (id, Data, Medicao, Loja, Consumo) 
  SELECT 1, NOW(), 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff',
         (SELECT Consumo FROM ENERGIA_L301B_Jorge_Bischoff_MEE185 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 2, NOW(), 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies',
         (SELECT Consumo FROM ENERGIA_L301F_American_Cookies_MEE181 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 3, NOW(), 'ENERGIA_L302_Reebok_MEE187', 'Reebok',
         (SELECT Consumo FROM ENERGIA_L302_Reebok_MEE187 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 4, NOW(), 'ENERGIA_L303_Polimaia_MEE188', 'Polimaia',
         (SELECT Consumo FROM ENERGIA_L303_Polimaia_MEE188 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 5, NOW(), 'ENERGIA_L305_Kipling_MEE190', 'Kipling',
         (SELECT Consumo FROM ENERGIA_L305_Kipling_MEE190 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 6, NOW(), 'ENERGIA_L150_DONPATTO_MEE259', 'Don Patto',
         (SELECT Consumo FROM ENERGIA_L150_DONPATTO_MEE259 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 7, NOW(), 'ENERGIA_L168_ILBARISTA_MEE275', 'IL BARISTA',
         (SELECT Consumo FROM ENERGIA_L168_ILBARISTA_MEE275 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 8, NOW(), 'ENERGIA_L169_L170_ZAK_MEE276', 'ZAK',
         (SELECT Consumo FROM ENERGIA_L169_L170_ZAK_MEE276 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 9, NOW(), 'ENERGIA_L193_L194_L195_CAROLBASSI_MEE293', 'CAROL BASSI',
         (SELECT Consumo FROM ENERGIA_L193_L194_L195_CAROLBASSI_MEE293 ORDER BY id DESC LIMIT 1);

-- Don Patto
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 282
WHERE Loja LIKE '%Don Patto%';

-- Brooksfield Donna
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 312
WHERE Loja LIKE '%Brooksfield Donna%';

-- Jorge Bischoff
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 652
WHERE Loja LIKE '%Jorge Bischoff%';

-- Reebok
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 655
WHERE Loja LIKE '%Reebok%';

-- Kipling
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 656
WHERE Loja LIKE '%Kipling%';

-- IL BARISTA
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 802
WHERE Loja LIKE '%IL BARISTA%';

-- ZAK
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 740
WHERE Loja LIKE '%ZAK%';

-- CAROL BASSI
UPDATE ENERGIA_GERAL_CONSOLIDADO
SET id_unidade = 643
WHERE Loja LIKE '%CAROL BASSI%';





END$$

CREATE DEFINER=`438522_automacao`@`%` EVENT `DELTA_CONSOLIDADDO_HISTORICO` ON SCHEDULE AT '2025-11-02 09:48:02' ON COMPLETION PRESERVE DISABLE DO INSERT INTO ENERGIA_GERAL_DELTA (Data, Medicao, Loja, ConsumoAtual, ConsumoAnterior, Delta)
SELECT 
    c.Data,
    c.Medicao,
    c.Loja,
    c.Consumo AS ConsumoAtual,
    h.Consumo AS ConsumoAnterior,
    c.Consumo - h.Consumo AS Delta
FROM ENERGIA_GERAL_CONSOLIDADO c
INNER JOIN (
    SELECT h1.Loja, h1.Consumo
    FROM ENERGIA_GERAL_HISTORICO h1
    INNER JOIN (
        SELECT Loja, MAX(Data) AS UltimaData
        FROM ENERGIA_GERAL_HISTORICO
        GROUP BY Loja
    ) h2 ON h1.Loja = h2.Loja AND h1.Data = h2.UltimaData
) h ON c.Loja = h.Loja$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
