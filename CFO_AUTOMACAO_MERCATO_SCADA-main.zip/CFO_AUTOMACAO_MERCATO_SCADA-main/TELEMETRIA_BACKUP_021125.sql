-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: mysql-automacao-cfo-energia.alwaysdata.net
-- Generation Time: Nov 02, 2025 at 12:59 PM
-- Server version: 10.11.14-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automacao-cfo-energia_cfoenergia`
--

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_CONSOLIDADO`
--

CREATE TABLE `ENERGIA_GERAL_CONSOLIDADO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_CONSOLIDADO`
--

INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`id`, `Data`, `Medicao`, `Loja`, `Consumo`) VALUES
(1, '2025-11-02 11:21:14', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8),
(2, '2025-11-02 11:21:15', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30515.1),
(3, '2025-11-02 11:21:38', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 308708);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_HISTORICO`
--

CREATE TABLE `ENERGIA_GERAL_HISTORICO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

CREATE TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301B',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301B_Jorge_Bischoff_MEE185',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

INSERT INTO `ENERGIA_L301B_Jorge_Bischoff_MEE185` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301B', 40761, '2025-11-02 12:00:58', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'SCADA_MYSQL', NULL, '2025-10-29 23:50:52', NULL, 40876.8);

--
-- Triggers `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301B` AFTER INSERT ON `ENERGIA_L301B_Jorge_Bischoff_MEE185` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Jorge Bischoff', NEW.Consumo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301F_American_Cookies_MEE181`
--

CREATE TABLE `ENERGIA_L301F_American_Cookies_MEE181` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301F',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301F_American_Cookies_MEE181',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301F_American_Cookies_MEE181`
--

INSERT INTO `ENERGIA_L301F_American_Cookies_MEE181` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301F', 30515, '2025-11-02 12:20:43', 'ENERGIA_L301F_American_Cookies_MEE181', 'SCADA_MYSQL', NULL, '2025-10-29 22:17:46', NULL, 30515.1);

--
-- Triggers `ENERGIA_L301F_American_Cookies_MEE181`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301F` AFTER INSERT ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'American Cookies', NEW.Consumo);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_data_value_before_update` BEFORE UPDATE ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L302_Reebok_MEE187`
--

CREATE TABLE `ENERGIA_L302_Reebok_MEE187` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L302',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L302_Reebok_MEE187',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L302_Reebok_MEE187`
--

INSERT INTO `ENERGIA_L302_Reebok_MEE187` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L302', NULL, '2025-11-02 12:20:13', 'ENERGIA_L302_Reebok_MEE187', 'SCADA_MYSQL', NULL, '2025-11-02 03:19:41', NULL, 308709);

--
-- Triggers `ENERGIA_L302_Reebok_MEE187`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L302` AFTER INSERT ON `ENERGIA_L302_Reebok_MEE187` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Reebok', NEW.Consumo);
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`438522_automacao`@`%` EVENT `salvar_historico_consolidado` ON SCHEDULE EVERY 15 MINUTE STARTS '2025-11-02 12:43:22' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  INSERT INTO ENERGIA_GERAL_HISTORICO (Data, Medicao, Loja, Consumo)
  SELECT Data, Medicao, Loja, Consumo
  FROM ENERGIA_GERAL_CONSOLIDADO;
END$$

CREATE DEFINER=`438522_automacao`@`%` EVENT `atualizar_consolidado` ON SCHEDULE EVERY 1 MINUTE STARTS '2025-11-02 12:40:51' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  -- Atualiza a tabela consolidada com os valores mais recentes de cada loja
  REPLACE INTO ENERGIA_GERAL_CONSOLIDADO (id, Data, Medicao, Loja, Consumo)
  SELECT 1, NOW(), 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 
         (SELECT Consumo FROM ENERGIA_L301B_Jorge_Bischoff_MEE185 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 2, NOW(), 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 
         (SELECT Consumo FROM ENERGIA_L301F_American_Cookies_MEE181 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 3, NOW(), 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 
         (SELECT Consumo FROM ENERGIA_L302_Reebok_MEE187 ORDER BY id DESC LIMIT 1);
END$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
