-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: mysql-automacao-cfo-energia.alwaysdata.net
-- Generation Time: Nov 02, 2025 at 04:20 AM
-- Server version: 10.11.14-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automacao-cfo-energia_cfoenergia`
--

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

CREATE TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301B',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301B_Jorge_Bischoff_MEE185',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

INSERT INTO `ENERGIA_L301B_Jorge_Bischoff_MEE185` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301B', 40761, '2025-11-02 04:20:04', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'SCADA_MYSQL', NULL, '2025-10-29 23:50:52', NULL, 40876.2);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301F_American_Cookies_MEE181`
--

CREATE TABLE `ENERGIA_L301F_American_Cookies_MEE181` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301F',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301F_American_Cookies_MEE181',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301F_American_Cookies_MEE181`
--

INSERT INTO `ENERGIA_L301F_American_Cookies_MEE181` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301F', 30515, '2025-11-02 04:19:42', 'ENERGIA_L301F_American_Cookies_MEE181', 'SCADA_MYSQL', NULL, '2025-10-29 22:17:46', NULL, 30514.6);

--
-- Triggers `ENERGIA_L301F_American_Cookies_MEE181`
--
DELIMITER $$
CREATE TRIGGER `update_data_value_before_update` BEFORE UPDATE ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L302_Reebok_MEE187`
--

CREATE TABLE `ENERGIA_L302_Reebok_MEE187` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L302',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L302_Reebok_MEE187',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L302_Reebok_MEE187`
--

INSERT INTO `ENERGIA_L302_Reebok_MEE187` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L302', NULL, '2025-11-02 04:20:03', 'ENERGIA_L302_Reebok_MEE187', 'SCADA_MYSQL', NULL, '2025-11-02 03:19:41', NULL, 308703);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
