-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Host: mysql-automacao-cfo-energia.alwaysdata.net
-- Generation Time: Nov 03, 2025 at 03:57 AM
-- Server version: 10.11.14-MariaDB
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `automacao-cfo-energia_cfoenergia`
--

DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`438522_automacao`@`%` PROCEDURE `AtualizaEnergiaGeral` ()   BEGIN
  DECLARE done INT DEFAULT FALSE;
  DECLARE tabela VARCHAR(255);
  DECLARE sql_text TEXT;

  -- Cursor para todas as tabelas que começam com ENERGIA_ e não sejam a tabela consolidada
  DECLARE cur CURSOR FOR
    SELECT table_name
    FROM information_schema.tables
    WHERE table_schema = DATABASE()
      AND table_name LIKE 'ENERGIA\_%'
      AND table_name <> 'ENERGIA_GERAL_CONSOLIDADO';

  DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

  OPEN cur;
  read_loop: LOOP
    FETCH cur INTO tabela;
    IF done THEN
      LEAVE read_loop;
    END IF;

    -- Monta e executa SQL dinâmico para inserir dados da tabela atual
    SET @sql_text = CONCAT(
      'INSERT INTO ENERGIA_GERAL_CONSOLIDADO (Data, Medicao, Loja, Consumo)
       SELECT timestamp, Medicao,
       SUBSTRING_INDEX(SUBSTRING_INDEX("', tabela, '", "_MEE", 1), "ENERGIA_", -1) AS Loja,
       Consumo
       FROM ', tabela, ';'
    );
    PREPARE stmt FROM @sql_text;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
  END LOOP;
  CLOSE cur;
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_CONSOLIDADO`
--

CREATE TABLE `ENERGIA_GERAL_CONSOLIDADO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_CONSOLIDADO`
--

INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`id`, `Data`, `Medicao`, `Loja`, `Consumo`) VALUES
(1, '2025-11-03 03:46:55', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8),
(2, '2025-11-03 03:46:55', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30515.1),
(3, '2025-11-03 03:46:55', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 308757),
(4, '2025-11-03 03:46:55', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123815);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_DELTA`
--

CREATE TABLE `ENERGIA_GERAL_DELTA` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `ConsumoAtual` float DEFAULT NULL,
  `ConsumoAnterior` float DEFAULT NULL,
  `Delta` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_DELTA`
--

INSERT INTO `ENERGIA_GERAL_DELTA` (`id`, `Data`, `Medicao`, `Loja`, `ConsumoAtual`, `ConsumoAnterior`, `Delta`) VALUES
(1, '2025-11-02 13:31:38', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30515.1, 30515.1, 0),
(2, '2025-11-02 13:31:38', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8, 40876.8, 0),
(6, '2025-11-03 03:46:55', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 308757, 308709, 48.25),
(11, '2025-11-03 03:46:55', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8, 40876.8, 0),
(19, '2025-11-03 03:46:55', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123815, 123815, 0);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_GERAL_HISTORICO`
--

CREATE TABLE `ENERGIA_GERAL_HISTORICO` (
  `id` int(11) NOT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT NULL,
  `Loja` varchar(255) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_GERAL_HISTORICO`
--

INSERT INTO `ENERGIA_GERAL_HISTORICO` (`id`, `Data`, `Medicao`, `Loja`, `Consumo`) VALUES
(1, '2025-11-02 13:31:38', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 40876.8),
(2, '2025-11-02 13:31:38', 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 30515.1),
(3, '2025-11-02 13:31:38', 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 308709),
(7, '2025-11-03 03:46:55', 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 123815);

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

CREATE TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301B',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301B_Jorge_Bischoff_MEE185',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--

INSERT INTO `ENERGIA_L301B_Jorge_Bischoff_MEE185` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301B', 40761, '2025-11-02 12:00:58', 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'SCADA_MYSQL', NULL, '2025-10-29 23:50:52', NULL, 40876.8);

--
-- Triggers `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301B` AFTER INSERT ON `ENERGIA_L301B_Jorge_Bischoff_MEE185` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Jorge Bischoff', NEW.Consumo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L301F_American_Cookies_MEE181`
--

CREATE TABLE `ENERGIA_L301F_American_Cookies_MEE181` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L301F',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L301F_American_Cookies_MEE181',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L301F_American_Cookies_MEE181`
--

INSERT INTO `ENERGIA_L301F_American_Cookies_MEE181` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L301F', 30515, '2025-11-02 12:20:43', 'ENERGIA_L301F_American_Cookies_MEE181', 'SCADA_MYSQL', NULL, '2025-10-29 22:17:46', NULL, 30515.1);

--
-- Triggers `ENERGIA_L301F_American_Cookies_MEE181`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L301F` AFTER INSERT ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'American Cookies', NEW.Consumo);
END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `update_data_value_before_update` BEFORE UPDATE ON `ENERGIA_L301F_American_Cookies_MEE181` FOR EACH ROW BEGIN
    SET NEW.data_value = NEW.Consumo;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L302_Reebok_MEE187`
--

CREATE TABLE `ENERGIA_L302_Reebok_MEE187` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L302',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L302_Reebok_MEE187',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L302_Reebok_MEE187`
--

INSERT INTO `ENERGIA_L302_Reebok_MEE187` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L302', NULL, '2025-11-02 15:47:24', 'ENERGIA_L302_Reebok_MEE187', 'SCADA_MYSQL', NULL, '2025-11-02 03:19:41', NULL, 308757);

--
-- Triggers `ENERGIA_L302_Reebok_MEE187`
--
DELIMITER $$
CREATE TRIGGER `insert_geral_L302` AFTER INSERT ON `ENERGIA_L302_Reebok_MEE187` FOR EACH ROW BEGIN
  INSERT INTO `ENERGIA_GERAL_CONSOLIDADO` (`Data`, `Medicao`, `Loja`, `Consumo`)
  VALUES (NEW.timestamp, NEW.Medicao, 'Reebok', NEW.Consumo);
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `ENERGIA_L305_Kipling_MEE190`
--

CREATE TABLE `ENERGIA_L305_Kipling_MEE190` (
  `id` int(11) NOT NULL,
  `data_point` varchar(255) DEFAULT 'L305',
  `data_value` int(11) DEFAULT NULL,
  `timestamp` datetime DEFAULT current_timestamp(),
  `Medicao` varchar(255) DEFAULT 'ENERGIA_L305_Kipling_MEE190',
  `Tipo` varchar(255) DEFAULT 'SCADA_MYSQL',
  `Observacao` varchar(255) DEFAULT NULL,
  `Data` datetime DEFAULT current_timestamp(),
  `Valor` decimal(10,2) DEFAULT NULL,
  `Consumo` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `ENERGIA_L305_Kipling_MEE190`
--

INSERT INTO `ENERGIA_L305_Kipling_MEE190` (`id`, `data_point`, `data_value`, `timestamp`, `Medicao`, `Tipo`, `Observacao`, `Data`, `Valor`, `Consumo`) VALUES
(1, 'L305', NULL, '2025-11-03 03:52:58', 'ENERGIA_L305_Kipling_MEE190', 'SCADA_MYSQL', NULL, '2025-11-03 03:05:46', NULL, 123815);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_DELTA`
--
ALTER TABLE `ENERGIA_GERAL_DELTA`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ENERGIA_L305_Kipling_MEE190`
--
ALTER TABLE `ENERGIA_L305_Kipling_MEE190`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_CONSOLIDADO`
--
ALTER TABLE `ENERGIA_GERAL_CONSOLIDADO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_DELTA`
--
ALTER TABLE `ENERGIA_GERAL_DELTA`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT for table `ENERGIA_GERAL_HISTORICO`
--
ALTER TABLE `ENERGIA_GERAL_HISTORICO`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `ENERGIA_L301B_Jorge_Bischoff_MEE185`
--
ALTER TABLE `ENERGIA_L301B_Jorge_Bischoff_MEE185`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `ENERGIA_L301F_American_Cookies_MEE181`
--
ALTER TABLE `ENERGIA_L301F_American_Cookies_MEE181`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `ENERGIA_L302_Reebok_MEE187`
--
ALTER TABLE `ENERGIA_L302_Reebok_MEE187`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `ENERGIA_L305_Kipling_MEE190`
--
ALTER TABLE `ENERGIA_L305_Kipling_MEE190`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

DELIMITER $$
--
-- Events
--
CREATE DEFINER=`438522_automacao`@`%` EVENT `salvar_historico_consolidado` ON SCHEDULE EVERY 15 DAY STARTS '2025-11-01 12:43:22' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
  INSERT INTO ENERGIA_GERAL_HISTORICO (Data, Medicao, Loja, Consumo)
  SELECT Data, Medicao, Loja, Consumo
  FROM ENERGIA_GERAL_CONSOLIDADO;
END$$

CREATE DEFINER=`438522_automacao`@`%` EVENT `atualizar_consolidado` ON SCHEDULE EVERY 3 SECOND STARTS '2025-11-02 09:11:51' ON COMPLETION NOT PRESERVE ENABLE DO BEGIN
 
  REPLACE INTO ENERGIA_GERAL_CONSOLIDADO (id, Data, Medicao, Loja, Consumo)
  SELECT 1, NOW(), 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 
         (SELECT Consumo FROM ENERGIA_L301B_Jorge_Bischoff_MEE185 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 2, NOW(), 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 
         (SELECT Consumo FROM ENERGIA_L301F_American_Cookies_MEE181 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 3, NOW(), 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 
         (SELECT Consumo FROM ENERGIA_L302_Reebok_MEE187 ORDER BY id DESC LIMIT 1);
END$$

CREATE DEFINER=`438522_automacao`@`%` EVENT `ENERGIA_CONSOLIDADO` ON SCHEDULE AT '2025-11-02 22:40:42' ON COMPLETION PRESERVE DISABLE DO BEGIN
 
 REPLACE INTO ENERGIA_GERAL_CONSOLIDADO (id, Data, Medicao, Loja, Consumo)
  SELECT 1, NOW(), 'ENERGIA_L301B_Jorge_Bischoff_MEE185', 'Jorge Bischoff', 
         (SELECT Consumo FROM ENERGIA_L301B_Jorge_Bischoff_MEE185 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 2, NOW(), 'ENERGIA_L301F_American_Cookies_MEE181', 'American Cookies', 
         (SELECT Consumo FROM ENERGIA_L301F_American_Cookies_MEE181 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 3, NOW(), 'ENERGIA_L302_Reebok_MEE187', 'Reebok', 
         (SELECT Consumo FROM ENERGIA_L302_Reebok_MEE187 ORDER BY id DESC LIMIT 1)
  UNION ALL
  SELECT 4, NOW(), 'ENERGIA_L305_Kipling_MEE190', 'Kipling', 
         (SELECT Consumo FROM ENERGIA_L305_Kipling_MEE190 ORDER BY id DESC LIMIT 1);

END$$

CREATE DEFINER=`438522_automacao`@`%` EVENT `DELTA_CONSOLIDADDO_HISTORICO` ON SCHEDULE AT '2025-11-02 09:48:02' ON COMPLETION PRESERVE DISABLE DO INSERT INTO ENERGIA_GERAL_DELTA (Data, Medicao, Loja, ConsumoAtual, ConsumoAnterior, Delta)
SELECT 
    c.Data,
    c.Medicao,
    c.Loja,
    c.Consumo AS ConsumoAtual,
    h.Consumo AS ConsumoAnterior,
    c.Consumo - h.Consumo AS Delta
FROM ENERGIA_GERAL_CONSOLIDADO c
INNER JOIN (
    SELECT h1.Loja, h1.Consumo
    FROM ENERGIA_GERAL_HISTORICO h1
    INNER JOIN (
        SELECT Loja, MAX(Data) AS UltimaData
        FROM ENERGIA_GERAL_HISTORICO
        GROUP BY Loja
    ) h2 ON h1.Loja = h2.Loja AND h1.Data = h2.UltimaData
) h ON c.Loja = h.Loja$$

DELIMITER ;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
